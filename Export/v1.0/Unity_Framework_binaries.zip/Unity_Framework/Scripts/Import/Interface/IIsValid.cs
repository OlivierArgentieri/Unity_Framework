namespace Unity_Framework.Scripts.Import.Interface
{
    public interface IIsValid
    {
        #region f/p
        bool IsValid { get; }
        #endregion
    }
}